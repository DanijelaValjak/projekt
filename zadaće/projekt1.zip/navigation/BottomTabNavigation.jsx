import { NavigationContainer } from "@react-navigation/native";
import{createNativeStackNavigator} from '@react-navigation/native-stack';
import { StatusBar } from "expo-status-bar";
import {StyleSheet, Text, View} from 'react-native';
import {useFonts} from 'expo-font';
import * as SplashScreen from "expo-splash-screen";
import { useCallback } from "react";
import BottomTabNavigation from '.navigation/BottomTabNavigation';

const Stack = createNativeStackNavigator();

export default function App(){
    const [fontLoaded] = useFonts({
        refular:require("./assets/fonts/Roboto/Roboto-Regular.ttf")
    })
}

const onLayoutRootView = useCallback(async() => {
    if(fontLoaded) {
            await SplashScreen.hideAsync();
        }
    }, [fontsLoaded]);

    if(!fontsLoaded){
        return null;
    }

    return(
        <NavigationContainer>
            <Stack.Navigator>
                <Stack.Screen
                    name='Bottom Navigation'
                    component={}
                    options={{headerShown:false}}>
        
                </Stack.Screen>
            </Stack.Navigator>
        </NavigationContainer>
    );


const styles= StyleSheet.create({
    container: {
        flex:1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        justifyContent: 'center',
    },
    textStyle: {
        fontFamily: "regular",
        fontSize:20,
    }
})    

