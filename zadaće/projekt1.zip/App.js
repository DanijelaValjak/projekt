import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';

import { createStackNavigator } from '@react-navigation/stack';
import { Home, Bills, Account, Scan, ScanBill, ManualInput} from './screens'; // Uvezite sve potrebne komponente



const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={Home} options={{ headerShown: false }} />
        <Stack.Screen name="Bills" component={Bills} />
        <Stack.Screen name="Account" component={Account} options={{ headerShown: false, modal: true }}/>
        <Stack.Screen name="Scan" component={Scan} />
        <Stack.Screen name="ManualInput" component={ManualInput} />
        <Stack.Screen name="ScanBill" component={ScanBill} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.naslov}>
        <Text style={styles.title}>Billy</Text>
        {/* Ostatak vaše aplikacije */}
      </View>
      <View style={styles.bottomNavigation}>
        {/* Navigacijska traka */}
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Home')}>
          <Ionicons name="home-outline" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Bills')}>
          <Ionicons name="newspaper-outline" size={24} color="black"></Ionicons>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Scan')}>
          <Ionicons name="barcode-outline" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Account')}>
          <Ionicons name="person-circle-outline" size={24} color="black" />
        </TouchableOpacity>
        {/* Dodajte više gumba prema potrebi */}
      </View>
      <View style={styles.line}></View>
    </View>
  );
  
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'start',
    marginTop: 50,
    backgroundColor: 'lightgrey'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 20,
  },
  naslov:{
    backgroundColor: 'lightblue',
    width: '100%',
  },
  bottomNavigation: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: "100%",
    height: 50,
    backgroundColor: 'white',
    paddingHorizontal: 40,
  },
  navButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderRadius: 5,
    paddingVertical:8
  },
  line: {
    height: 1,
    backgroundColor: 'black',
    width: '100%',
  },
});



export default App;