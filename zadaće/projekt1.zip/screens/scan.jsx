import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";

const Scan = ({ navigation }) => {
  const handleScanPress = () => {
    navigation.navigate("ScanBill"); // Promijenjeno ime ekrana
  };

  const handleAddManuallyPress = () => {
    navigation.navigate("ManualInput"); // Promijenjeno ime ekrana
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={handleScanPress}>
        <Text style={styles.buttonText}>Scan the bill</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={handleAddManuallyPress}>
        <Text style={styles.buttonText}>Add manually</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  button: {
    backgroundColor: "blue",
    padding: 10,
    borderRadius: 5,
    margin: 10,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
  },
});

export default Scan;
