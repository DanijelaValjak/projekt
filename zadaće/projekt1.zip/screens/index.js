import Home from "./home";
import Bills from "./bills";
import Account from "./account";
import Scan from "./scan";
import ScanBill from "./ScanBill"
import ManualInput from "./ManualInput";



export{
    Home,
    Bills,
    Account,
    Scan,
    ScanBill,
    ManualInput,
}