import React, { useState } from "react";
import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Modal } from "react-native";
import { Ionicons } from '@expo/vector-icons';

const Home = ({ navigation }) => {
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  const accountBalance = '1,482,00';
  const recentTransactions = [
    { id: 1, description: "Shopping", amount: '56,89  -', billDate: "01/04/2024", status: "Completed" },
    { id: 2, description: "Salary", amount: '1500,00  +', billDate: "05/04/2024", status: "Completed" },
    { id: 3, description: "Electricity bill", amount: '53,28  -', billDate: "10/04/2024", status: "Pending" },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.line}></View>
      <View style={styles.accountContainer}>
        <Text style={styles.accountTitle}>Total Balance:</Text>
        <View style={styles.accountBalance}>
          <Text style={styles.balanceAmount}>€{accountBalance}</Text>
        </View>
      </View>
      <View style={styles.line}></View>
      <View style={styles.transactionsContainer}>
        <Text style={styles.transactionsTitle}>Recent transactions:</Text>
        {recentTransactions.map((transaction) => (
          <TouchableOpacity key={transaction.id} onPress={() => setSelectedTransaction(transaction)}>
            <View style={styles.transactionItem}>
              <View style={styles.bulletPoint}></View>
              <View style={styles.transactionContent}>
                <Text style={styles.transactionDescription}>{transaction.description}</Text>
                <Text style={styles.transactionAmount}>€{transaction.amount}</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>
      {selectedTransaction && (
        <Modal visible={!!selectedTransaction} transparent animationType="slide">
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalText}>Description: {selectedTransaction.description}</Text>
              <Text style={styles.modalText}>Amount: €{selectedTransaction.amount}</Text>
              <Text style={styles.modalText}>Bill Date: {selectedTransaction.billDate}</Text>
              <Text style={styles.modalText}>Status: {selectedTransaction.status}</Text>
              <TouchableOpacity onPress={() => setSelectedTransaction(null)}>
                <Text style={styles.closeButton}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      <View style={styles.bottomNavigation}>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Home')}>
          <Ionicons name="home-outline" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Bills')}>
          <Ionicons name="newspaper-outline" size={24} color="black"></Ionicons>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Scan')}>
          <Ionicons name="barcode-outline" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Account')}>
          <Ionicons name="person-circle-outline" size={24} color="black" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
    backgroundColor: 'lightgrey'
  },
  accountContainer: {
    alignItems: 'center',
    backgroundColor: 'white',
    justifyContent: 'center',
    height: '20%',
    width: '80%',
    marginLeft: 40,
  },
  accountTitle: {
    fontSize: 18,
    marginBottom: 20,
    marginTop: 10,
  },
  accountBalance: {
    borderWidth: 1,
    borderColor: 'black',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  balanceAmount: {
    fontSize: 24,
    fontWeight: "bold",
  },
  line: {
    height: 1,
    backgroundColor: 'black',
    width: '100%',
    marginVertical: 20,
  },
  transactionsContainer: {
    width: '100%',
  },
  transactionsTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
    marginLeft: 5,
    padding: 5,
    borderRadius: 5,
  },
  transactionItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 5,
    width: '80%',
    marginLeft: 30,
  },
  bulletPoint: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'black',
    marginRight: 10,
  },
  transactionContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    flex: 1,
  },
  transactionDescription: {
    fontSize: 15,
    flex: 1,
  },
  transactionAmount: {
    fontWeight: "bold",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  modalContent: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  modalText: {
    fontSize: 15,
    marginBottom: 5,
  },
  closeButton: {
    marginTop: 15,
    color: "blue",
    alignSelf: "center",
  },
  bottomNavigation: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: "100%",
    height: 50,
    backgroundColor: 'white',
    paddingHorizontal: 40,
  },
  navButton: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderRadius: 5,
    paddingVertical: 8,
  },
});

export default Home;
