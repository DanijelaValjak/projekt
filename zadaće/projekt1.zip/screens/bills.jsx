import React, { useState } from "react";
import { StyleSheet, Text, View, SafeAreaView, TextInput, FlatList, TouchableOpacity, Modal } from "react-native";
import ManualInput from "./ManualInput";

const Bills = () => {
  const [billsData, setBillsData] = useState([
    { id: 1, number: '0010401', billDate: "01/04/2024", amount: '53,28 €', description: 'Electricity bill', status: 'Approved' },
    { id: 2, number: '0020405', billDate: "05/04/2024", amount: '40,00 €', description: 'Water bill', status: 'Pending' },
    { id: 3, number: '0030410', billDate: "10/04/2024", amount: '80,59 €', description: 'Internet bill', status: 'Declined' },
    { id: 4, number: '0040415', billDate: "15/04/2024", amount: '46,89 €', description: 'Phone bill', status: 'Approved' },
    { id: 5, number: '0050420', billDate: "20/04/2024", amount: '38,93 €', description: 'Gas bill', status: 'Pending' },
  ]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBill, setSelectedBill] = useState(null);

  const searchBills = () => {
    const filteredBills = billsData.filter(
      (bill) =>
        bill.number.toString().includes(searchQuery) ||
        bill.billDate.includes(searchQuery) ||
        bill.amount.toString().includes(searchQuery) ||
        bill.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return filteredBills;
  };

  const renderBillItem = ({ item }) => (
    <TouchableOpacity onPress={() => setSelectedBill(item)}>
      <View style={styles.billContainer}>
        <Text style={styles.billText}>Number: {item.number}</Text>
        <Text style={styles.billText}>Bill Date: {item.billDate}</Text>
        <Text style={styles.billText}>Amount: {item.amount}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <TextInput
        style={styles.searchInput}
        onChangeText={(text) => setSearchQuery(text)}
        value={searchQuery}
        placeholder="Search bills..."
      />
      <FlatList
        data={searchBills()}
        renderItem={renderBillItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.flatListContent}
      />
      {selectedBill && (
        <Modal visible={!!selectedBill} transparent animationType="slide">
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalText}>Number: {selectedBill.number}</Text>
              <Text style={styles.modalText}>Bill Date: {selectedBill.billDate}</Text>
              <Text style={styles.modalText}>Amount: {selectedBill.amount}</Text>
              <Text style={styles.modalText}>Description: {selectedBill.description}</Text>
              <Text style={styles.modalText}>Status: {selectedBill.status}</Text>
              <TouchableOpacity onPress={() => setSelectedBill(null)}>
                <Text style={styles.closeButton}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
    paddingHorizontal: 10,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    width: "80%",
    marginBottom: 20,
  },
  billContainer: {
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 10,
    padding: 10,
    marginBottom: 20,
    width: "100%",
    backgroundColor: "white",
  },
  billText: {
    fontSize: 15,
    marginBottom: 5,
  },
  flatListContent: {
    flexGrow: 1,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  modalContent: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  modalText: {
    fontSize: 15,
    marginBottom: 5,
  },
  closeButton: {
    marginTop: 15,
    color: "blue",
    alignSelf: "center",
  },
});

export default Bills;
