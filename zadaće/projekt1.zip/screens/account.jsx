import React, { useState } from "react";
import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, Modal, TextInput } from "react-native";
import { useNavigation } from '@react-navigation/native'; 

const Account = () => {
  const [notificationEnabled, setNotificationEnabled] = useState(false); 
  const [openChangePasswordModal, setOpenChangePasswordModal] = useState(false); 
  const [newPassword, setNewPassword] = useState(''); 

  const userData = {
    username: "danijela_valjak",
    firstName: "Danijela",
    lastName: "Valjak",
    email: "valjakdanijela00@gmail.com",
  };

  const navigation = useNavigation(); 

  const handleNotificationToggle = () => {
    setNotificationEnabled(!notificationEnabled);
  };

  const handleChangePassword = () => {
    setOpenChangePasswordModal(true);
  };

  const handleGoBack = () => {
    navigation.goBack();
  };

  const handleSavePassword = () => {
    setOpenChangePasswordModal(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.goBackButton} onPress={handleGoBack}>
          <Text style={styles.goBackText}>Home</Text>
        </TouchableOpacity>
      </View>
      <Image
          style={styles.profileImage}
          source={require("C:/Users/Danijela Valjak/Desktop/3.godina/projekt/assets/1.jpg")}
        />
      <View style={styles.userInfoContainer}>
        <View style={styles.userInfoField}>
          <Text style={styles.userInfoLabel}>Username:</Text>
          <Text style={styles.userInfoValue}>{userData.username}</Text>
        </View>
        <View style={styles.userInfoField}>
          <Text style={styles.userInfoLabel}>Name:</Text>
          <Text style={styles.userInfoValue}>{userData.firstName} {userData.lastName}</Text>
        </View>
        <View style={styles.userInfoField}>
          <Text style={styles.userInfoLabel}>Email:</Text>
          <Text style={styles.userInfoValue}>{userData.email}</Text>
        </View>
      </View>
      <View style={styles.actionContainer}>
        <TouchableOpacity style={styles.actionButton} onPress={handleNotificationToggle}>
          <Text style={styles.actionButtonText}>{notificationEnabled ? 'Disable Notifications' : 'Enable Notifications'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton} onPress={handleChangePassword}>
          <Text style={styles.actionButtonText}>Change Password</Text>
        </TouchableOpacity>
      </View>
      <Modal visible={openChangePasswordModal} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Enter new password:</Text>
            <TextInput
              style={styles.input}
              value={newPassword}
              onChangeText={setNewPassword}
              placeholder="New Password      "
              secureTextEntry={true}
            />
            <View style={styles.buttonContainer}>
              <TouchableOpacity style={styles.saveButton} onPress={handleSavePassword}>
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.closeButton} onPress={() => setOpenChangePasswordModal(false)}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    padding: 20,
    marginTop: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: "100%",
    marginBottom: 20,
  },
  goBackButton: {
    alignSelf: 'flex-start',
    marginLeft: 20,
  },
  goBackText: {
    color: 'blue',
    fontSize: 16,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    marginBottom: 20,
  },
  userInfoContainer: {
    width: "100%",
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },
  userInfoField: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  userInfoLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
  },
  userInfoValue: {
    fontSize: 16,
  },
  actionContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    width: "80%",
    marginBottom: 20,
  },
  actionButton: {
    backgroundColor: "lightblue",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginBottom: 20,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  modalContent: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  modalText: {
    fontSize: 12,
    marginBottom: 10,
  },
  input: {
    width: "100%",
    backgroundColor: "#eee",
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  saveButton: {
    backgroundColor: "lightblue",
    padding: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  saveButtonText: {
    fontSize: 15,
    fontWeight: "bold",
    color: "white",
  },
  closeButton: {
    backgroundColor: "grey",
    padding: 10,
    borderRadius: 5,
  },
  closeButtonText: {
    fontSize: 15,
    fontWeight: "bold",
    color: "white",
  },
});

export default Account;
